package com.example.SpringBoot_ThymeleafCrudTutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootThymeleafCrudTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootThymeleafCrudTutorialApplication.class, args);
	}

}

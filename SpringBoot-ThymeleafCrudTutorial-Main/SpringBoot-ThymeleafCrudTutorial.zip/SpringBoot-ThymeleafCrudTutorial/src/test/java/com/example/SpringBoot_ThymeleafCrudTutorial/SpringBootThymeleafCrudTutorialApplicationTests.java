package com.example.SpringBoot_ThymeleafCrudTutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootThymeleafCrudTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
